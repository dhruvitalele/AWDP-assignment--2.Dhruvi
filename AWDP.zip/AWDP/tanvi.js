// Quantity
let qty = [1, 1, 1, 1, 1, 1, 1, 1];

function increase(i) {
    qty[i]++;
    document.getElementById("qty" + i).innerText = qty[i];
}

function decrease(i) {
    if (qty[i] > 1) {
        qty[i]--;
        document.getElementById("qty" + i).innerText = qty[i];
    }
}

// Show / Hide Details
function toggleDetails(btn) {

    let card = btn.closest(".card");
    let details = card.querySelector(".details");

    if (details.style.display === "block") {
        details.style.display = "none";
        btn.innerText = "Show Details";
    } else {
        details.style.display = "block";
        btn.innerText = "Hide Details";
    }
}

// Add To Cart
let cart = JSON.parse(localStorage.getItem("cart")) || []

document.querySelectorAll(".add-cart").forEach(function(button){

    button.addEventListener("click", function(){

        let card = this.closest(".card");

        let name = this.dataset.name;
        let price = this.dataset.price;
        let image = this.dataset.image;

        let qtySpan = card.querySelector("span[id^='qty']");
        let quantity = parseInt(qtySpan.innerText);

        cart.push({
            name,
            price,
            image,
            quantity
        });

        localStorage.setItem("cart", JSON.stringify(cart));

        alert(name + " added to cart!");
    });

});

// Category Filter
function showCategory(category){

    let cards = document.querySelectorAll(".card");

    cards.forEach(function(card){

        if(category === "all"){
            card.style.display="block";
        }
        else if(card.classList.contains(category)){
            card.style.display="block";
        }
        else{
            card.style.display="none";
        }

    });

}

// Image Zoom
function zoomIn(img){
    img.style.transform="scale(1.1)";
    img.style.transition="0.3s";
}

function zoomOut(img){
    img.style.transform="scale(1)";
}
