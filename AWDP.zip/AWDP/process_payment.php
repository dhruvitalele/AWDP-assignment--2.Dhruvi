<?php
include 'db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $full_name = $_POST['full_name'];
    $email = $_POST['email'];
    $mobile = $_POST['mobile'];
    $address = $_POST['address'];
    $payment_method = $_POST['payment_method'];

    $sql = "INSERT INTO orders (full_name, email, mobile, address, payment_method) 
            VALUES ('$full_name', '$email', '$mobile', '$address', '$payment_method')";

    if ($conn->query($sql) === TRUE) {
        echo "<script>alert('Order Placed Successfully!'); window.location.href='payment.html';</script>";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }

    $conn->close();
}
?>
