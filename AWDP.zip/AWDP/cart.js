// Get cart from localStorage
let cart = JSON.parse(localStorage.getItem("cart")) || [];

const cartContainer = document.getElementById("cartItems");
const totalItems = document.getElementById("totalItems");
const totalPrice = document.getElementById("totalPrice");
const emptyCart = document.getElementById("emptyCart");

function saveCart() {
    localStorage.setItem("cart", JSON.stringify(cart));
}

function displayCart() {

    cartContainer.innerHTML = "";

    if(cart.length === 0){

        emptyCart.style.display="block";
        document.querySelector(".cart-summary").style.display="none";
        return;

    }

    emptyCart.style.display="none";
    document.querySelector(".cart-summary").style.display="block";

    let total = 0;
    let items = 0;

    cart.forEach((product,index)=>{

        total += product.price * product.quantity;
        items += product.quantity;

        cartContainer.innerHTML += `

        <div class="cart-item">

            <img src="${product.image}" alt="">

            <div class="item-details">

                <h3>${product.name}</h3>

                <p class="price">₹${product.price}</p>

                <div class="quantity">

                    <button onclick="decrease(${index})">-</button>

                    <span>${product.quantity}</span>

                    <button onclick="increase(${index})">+</button>

                </div>

            </div>

            <button class="remove-btn" onclick="removeItem(${index})">
            Remove
            </button>

        </div>

        `;

    });

    totalItems.innerHTML = items;
    totalPrice.innerHTML = total;

}

function increase(index){

    cart[index].quantity++;

    saveCart();

    displayCart();

}

function decrease(index){

    if(cart[index].quantity>1){

        cart[index].quantity--;

    }else{

        cart.splice(index,1);

    }

    saveCart();

    displayCart();

}

function removeItem(index){

    cart.splice(index,1);

    saveCart();

    displayCart();

}

function checkout(){

    if(cart.length===0){

        alert("Cart is Empty!");

        return;

    }

    window.location.href="payment.html";

}

displayCart();