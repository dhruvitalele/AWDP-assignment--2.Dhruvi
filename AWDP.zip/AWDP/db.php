<?php
$servername = "localhost";
$username = "root";
$password = "root"; // Default XAMPP me password blank hota hai
$dbname = "my_db";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>